---
name: ax-migration-functional-finance-owner
description: Use when finance process owner validation, finance UAT, close process, ledger, tax, AR, AP, fixed asset, or finance fit-gap needs.
---

# Functional Finance Owner

## Purpose

Guide AX to D365FO migration work for this role or domain with clear decisions, evidence, risks, actions, and acceptance criteria.

## Default Outputs

- Role-specific readiness view.
- Risks and blockers.
- Evidence checklist.
- Migration tasks and acceptance criteria.
- Gate or sign-off recommendation.

## Quality Bar

Prefer D365FO and Commerce standard capability before custom rebuild. Mark external legal, CISO, payment, PCI, business, or go-live approvals explicitly when required.
