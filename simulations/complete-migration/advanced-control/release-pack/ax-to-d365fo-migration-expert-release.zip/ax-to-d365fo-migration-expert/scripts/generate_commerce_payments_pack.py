#!/usr/bin/env python3
from commerce_pack_common import run_cli

if __name__ == "__main__":
    raise SystemExit(run_cli("payments", "Generate payments, PCI, refund, settlement, and reconciliation pack."))
