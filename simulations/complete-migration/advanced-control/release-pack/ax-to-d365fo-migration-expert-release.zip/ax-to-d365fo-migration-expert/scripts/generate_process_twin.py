#!/usr/bin/env python3
from governance_pack_common import run_cli

if __name__ == "__main__":
    raise SystemExit(run_cli("process-twin", "Generate end-to-end process twin."))
